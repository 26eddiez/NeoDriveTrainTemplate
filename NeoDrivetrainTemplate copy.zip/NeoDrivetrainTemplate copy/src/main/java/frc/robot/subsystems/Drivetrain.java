package frc.robot.subsystems;

import com.ctre.phoenix.sensors.Pigeon2;

import edu.wpi.first.math.Matrix;
import edu.wpi.first.math.VecBuilder;
import edu.wpi.first.math.controller.ProfiledPIDController;
import edu.wpi.first.math.estimator.SwerveDrivePoseEstimator;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.kinematics.SwerveDriveKinematics;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N3;
import edu.wpi.first.math.trajectory.TrapezoidProfile.Constraints;
import edu.wpi.first.util.sendable.SendableBuilder;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.RobotMap;
import frc.robot.util.SwerveModule;

public class Drivetrain extends SubsystemBase {
    private static Drivetrain instance;

    private SwerveModule[] swerveModules;

    private SwerveDriveKinematics kinematics;

    /*
     * Constructor of Drivetrain.
     * - Instantiates 4 swerve modules with ids (0, 1, 2, 3) in an array of 
     * SwerveModules (see the instance variable)
     * - Instantiates a new SwerveDriveKinematics for the 4 swerve modules
     *      - Constructor takes in 4 Translation2ds: 
     *          (l/2, w/2), (l/2, -w/2), (-l/2, w/2), (-l/2, -w/2)
     */
    private Drivetrain() {
        /* INSERT CODE HERE!!! */
    }

    /*
     * Returns the kinematics of the drivetrain.
     */
    public SwerveDriveKinematics getKinematics() {
        /* INSERT CODE HERE!!! */
        return null; // replace
    }

    /*
     * Sets the speed and rotation of all the swerve modules.
     * - Converts the chassisSpeeds to a SwerveModuleState (use a method under kinematics)
     * - For each SwerveModulel, set the angle and drive by passing in its
     * respective SwerveModuleState
     */
    public void setAngleAndDrive(ChassisSpeeds chassisSpeeds) {
        /* INSERT CODE HERE!!! */
    }

    /*
     * Returns all of the SwerveModule positions.
     * - Return a new SwerveModulePosition array containing the returned
     * SwerveModulePosition from the getSwerveModulePosition() of each swerve module
     */
    public SwerveModulePosition[] getModulePositions() {
        /* INSERT CODE HERE!!! */
        return null; // replace
    }
    

    @Override
    public void periodic() {
        // leave empty for now
    }

    /*
     * SINGLETON CODE!
     */
    public static Drivetrain getInstance() {
        /* INSERT CODE HERE!!! */
        return null; // replace
    }
    
    /**
     * Smart Dashboard debugging and tuning.
     */
    @Override
    public void initSendable(SendableBuilder builder) {
        builder.setSmartDashboardType("Drivetrain");
        builder.setActuator(true);
        builder.setSafeState(() -> setAngleAndDrive(new ChassisSpeeds()));
        // builder.addDoubleProperty("Pitch Value", () -> getPitch(), null);
        // builder.addDoubleProperty("Roll Value", () -> getRoll(), null);

        for (int i = 0; i < 4; i++) {
        builder.addDoubleProperty(
            SwerveModule.swerveIDToName(i) + " Translation Speed", swerveModules[i]::getSpeed, null);
        builder.addDoubleProperty(
            SwerveModule.swerveIDToName(i) + " Translation Position",
            swerveModules[i]::getWheelPosition,
            null);
        builder.addDoubleProperty(
            SwerveModule.swerveIDToName(i) + " Rotation Angle", swerveModules[i]::getAngle, null);
        }
    }
}
