package frc.robot.subsystems;

public class Shooter {
    /**
     * Start by making what you need in every subsystem
     */
    /**
     * First make two VictorSPX motors for the shooter, one master, one follower 
     */
    /**
     * Create a feedforward loop, same as you did in swerve module 
     */
    /**
     * In your constructor, you want to initialzie both motors to their corresponding ports ( constants in robot map)
     * intiialize your feedforward values (constants in robotmap)
     */
    private Shooter() {

    }
    /**
     * Config follower motor 
     * Config factory Default 
     * set inverts
     * set neutral mode to coast 
     * disable soft limits 
     * config PIDs (constants in robotmap)
     */
    public void initMotors() {

    }
    /**
     * Calculate the velocity needed using the feedforward loop 
     */
    public void setVelocity(double velocity) {

    }
    /**
     * use the getSelectedSensorVelocity method and convert it to rotations per second (constant in robotmap )
     * @return
     */
    public double getVelocity() {

        return 0;
    }

}
