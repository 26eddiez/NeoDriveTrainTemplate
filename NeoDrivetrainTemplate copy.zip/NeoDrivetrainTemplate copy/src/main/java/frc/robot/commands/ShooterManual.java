package frc.robot.commands;


/**
 * What type of command do you think this would be?
 */

public class ShooterManual {
    /**
     * What do you need in the constructor? 
     */
    public ShooterManual() {

    }
    /**
     * Set the shooter to a certain velocity (constant in robotmap) if one of the buttons on the gamepad is pressed
     * otherwise the velocity should be zero
     */
    public void execute() {

    }
    /**
     * What is the final method and what should you do in that method 
     */
}
