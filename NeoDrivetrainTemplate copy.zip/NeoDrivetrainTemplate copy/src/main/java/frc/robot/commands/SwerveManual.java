package frc.robot.commands;

import edu.wpi.first.math.kinematics.ChassisSpeeds;
import frc.robot.OI;
import frc.robot.RobotMap;
import frc.robot.subsystems.Drivetrain;
import harkerrobolib.commands.IndefiniteCommand;
import harkerrobolib.util.Constants;
import harkerrobolib.util.MathUtil;

public class SwerveManual extends IndefiniteCommand {

    private double vx, vy, omega;

    /**
     * Constructor for SwerveManual.
     * - addRequirements for drivetrain
     * - set vx, vy, and omega to 0
     */
    public SwerveManual() {
        /* INSERT CODE HERE!!! */
    }

    /**
     * Overriden execute method
     * - Get the x, y, and rotational velocities from the driver joystick
     *      - vx/vy/omega = MathUtil.mapJoystickOutput(lefty/leftx/rightx, deadband in Constants class)
     *      - note that vy is the NEGATIVE of the mapped joystick output
     * - scale the velocities based on multipliers by calling the scaleValues() method
     *      -  pass in the max speeds from the Constants class in RobotMap
     * - sets velocities to zero if robot is not visibly moving (use isRobotStill())
     * - sets the rotational velocity to 0.0001 if the absolute value of omega is less than
     * the minimumm output (in RobotMap)
     * - call the setAngleAndDrive() method in drivetrain and pass in a
     * chassisSpeeds containing vx, vy, and omega
     */
    public void execute() {
        /* INSERT CODE HERE! */
    }

    /**
     * Scales the velocities by their given multiplier
     * @param value         velocity to scale
     * @param scaleFactor   multiplier
     * @return              scaled velocity
     */
    private double scaleValues(double value, double scaleFactor) {
        /* INSERT CODE HERE! */
        return 0; // replace
    }

    /**
     * @return if the robot is moving slow enough for it to be considered still
     *          if the magnitude of the velocity (sqrt of vx^2 + vy^2) is less
     *          than the minimum output
     */
    private boolean isRobotStill() {
        /* INSERT CODE HERE! */
        return false; // replace
    }

    /**
     * Sets the x, y, and rotational velocities to 0.
     * - calls the setAngleAndDrive method in drivetrain and passes in
     * a new ChassisSpeeds()
     */
    public void end(boolean interrupted) {
        /* INSERT CODE HERE! */
    }
}