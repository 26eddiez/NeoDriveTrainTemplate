package frc.robot.util;

import com.ctre.phoenix.sensors.CANCoder;
import com.ctre.phoenix.sensors.SensorInitializationStrategy;
import com.revrobotics.CANSparkMax;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.SparkMaxPIDController;
import com.revrobotics.CANSparkMax.IdleMode;
import com.revrobotics.CANSparkMaxLowLevel.MotorType;

import edu.wpi.first.math.controller.SimpleMotorFeedforward;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import frc.robot.RobotMap;
import harkerrobolib.util.Constants;

/**
 * READ ME!!!!!!!!!
 * - If you are unsure what type each variable type or parameter type should be,
 * remember to hover over the method or check the instance variables
 * - Remember to use constants from RobotMap.java
 * - Do sampleVariable. and then scroll through the list of methods if you
 * don't remember the name
 */

public class SwerveModule {

    private int id;

    private CANSparkMax translation;
    private CANSparkMax rotation;

    private SparkMaxPIDController translationController;
    private SparkMaxPIDController rotationController;

    private RelativeEncoder translationEncoder;
    private RelativeEncoder rotationEncoder;

    private CANCoder canCoder;

    private SimpleMotorFeedforward feedforward;


    /**
     * Constructor of the Swerve module.
     * - Sets swerve module's id as the id passed in through the constructor
     * - Instantiates a new translation motor
     *      - sets inverted based on the translation inverts in robotmap
     *      - sets the translaton controller and translation encoder
     * - do the same thing for he roation encoder
     * - instantiate the cancoder
     * - instantiate the feedforward
     * - call the helper method initModule()
     */
    public SwerveModule(int id) {
        /* INSERT CODE HERE!!! */
    }

    /*
     * Configures all the translation motor settings.
     * Does the following things:
     * - restores factory defaults
     * - sets smart current limit
     * - sets the idle mode (brake mode)
     * - sets the voltage compensation
     * - sets the p, i, and d values on the translation controller
     * - sets the position of the encoder to 0
     * - sets the position and velocity conversion factors for the encoder
     */
    public void configTranslation() {
        /* INSERT CODE HERE!!! */
    }

    /*
     * Configures all the rotation motor settings.
     * Does the following things:
     * - restores factory defaults
     * - sets smart current limit
     * - sets the idle mode (brake mode)
     * - sets the voltage compensation
     * - sets the p, i, and d values on the rotation controller
     * - sets the position of the encoder
     * - sets the position conversion factors for the encoder
     * - call setAbsolutePosition()
     */
    public void configRotation() {
        /* INSERT CODE HERE!!! */
    }

    /*
     * Initializes the module.
     * - Configs the factory default of the canCoder
     * - clears the sticky faults of the canCoder
     * - configs the sensor intialization strategy of canCoder (boot to absolute position)
     * - sets position to absolute of the canCoder
     * - calls configTranslation() and configRotation()
     */
    public void initModule() {

        /* INSERT CODE HERE!!! */
    }

    /*
     * Sets the angle and drive of the swerve module and updates SmartDashboard accordingly.
     * - Calls the optimize() method
     * - Sets the reference for the translationController
     * - Sets the reference for the rotationController
     * - optional: add numbers to smart dashboard (search up on google)
     */
    public void setAngleAndDrive(SwerveModuleState state) {
        /* INSERT CODE HERE!!! */
    }

    /*
     * Optimizes the swerve module state so that robot turns less
     * and just reverses the wheels.
     */
    public SwerveModuleState optimize(SwerveModuleState desiredState) {
        double currentAngle = Math.toRadians(getAngle());
        double targetAngle = Math.IEEEremainder(desiredState.angle.getRadians(), Math.PI * 2);
        double remainder = currentAngle % (Math.PI * 2);

        var adjusted = targetAngle + currentAngle - remainder;
        var speed = desiredState.speedMetersPerSecond;

        if (adjusted - currentAngle > Math.PI) {
            adjusted -= Math.PI * 2;
        }
        if (adjusted - currentAngle < -Math.PI) {
            adjusted += Math.PI * 2;
        }

        if (adjusted - currentAngle > Math.PI / 2) {
            adjusted -= Math.PI;
            speed *= -1;
        } else if (adjusted - currentAngle < -Math.PI / 2) {
            adjusted += Math.PI;
            speed *= -1;
        }

        return new SwerveModuleState(speed, Rotation2d.fromRadians(adjusted));
    }

    /*
     * Sets the position of the rotation encoder to the absolute position of the
     * canCoder minus the canCoder offset (RobotMap.java)
     * Optional: put cancoder absolute position on smart dashboard (google if you don't know)
     */
    private void setAbsolutePosition() {
        /* INSERT CODE HERE!!! */
    }

    /*
     * Sets the position of the translation encoder to 0. Ensures that the
     * translation motor is "zeroed".
     */
    public void zeroTranslation() {
        /* INSERT CODE HERE!!! */
    }

    /*
     * Returns the angle of the swerve module, which is represented by the position
     * on the rotation motor. (get value from ENCODER)
     */
    public double getAngle() {
        /* INSERT CODE HERE!!! */
        return 0; // replace
    }

    /*
     * Returns the speed of the swerve module, which is represented by the velocity
     * of the translation motor. (get value from ENCODER)
     */
    public double getSpeed() {
        /* INSERT CODE HERE!!! */
        return 0; // replace
    }

    /*
     * Returns the position of the swerve module, which is represented by the position
     * of the translation motor. (get value from ENCODER)
     */
    public double getWheelPosition() {
        /* INSERT CODE HERE!!! */
        return 0; // replace
    }

    /*
     * Returns a new SwerveModulePosition using the wheel position and the angle
     * (use Rotation2d.fromDegrees(getAngle()))
     */
    public SwerveModulePosition getSwerveModulePosition() {
        /* INSERT CODE HERE!!! */
        return null; // replace
    }

    /*
     * Returns a new SwerveModuleState using the wheel speed and the angle
     * (use Rotation2d.fromDegrees(getAngle()))
     */
    public SwerveModuleState getSwerveModuleState() {
        /* INSERT CODE HERE!!! */
        return null; // replace
    }

    /*
     * Helpful conversion from id name to actual motor name.
     * USED FOR SMART DASHBOARD + DEBUGGING.
     */
    public static String swerveIDToName(int swerveID) {
        String output = "";
        if (swerveID < 2) output += "Front ";
        else output += "Back ";
        if (swerveID % 2 == 0) output += "Left";
        else output += "Right";
        return output;
    }
}
