package frc.robot;

import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.smartdashboard.Field2d;

public class RobotMap {

    public static final class Shooter {
        public static final double SHOOTER_GEAR_RATIO = 5.0;
        public static final double VICTOR_VELOCITY_TO_ROTATIONS_PER_SECOND = 10.0 / 2048.0 / SHOOTER_GEAR_RATIO;
        public static final int MASTER_ID = 20;
        public static final int FOLLOWER_ID = 21;
        public static final boolean MASTER_INVERT = false; // TODO
        public static final boolean FOLLOWER_INVERT = false; // TODO
        public static final double SHOOTER_VELOCITY = 30.0; // TODO
    }
    public static final class Field {
        public static final double fieldLength = Units.inchesToMeters(651.25);
        public static final double fieldWidth = Units.inchesToMeters(315.5);

        public static final Field2d FIELD = new Field2d();
    }

    public static final class Constants {
        public static final double ROBOT_LENGTH = Units.inchesToMeters(30);
        public static final double ROBOT_WIDTH = Units.inchesToMeters(28);

        public static final double MAX_DRIVING_SPEED = 4.0; // m/s
        public static final double MAX_ANGLE_VELOCITY = Math.PI;

        public static final String CAN_CHAIN = "rio";

        public static final double WHEEL_DIAMETER = Units.inchesToMeters(4.0); //TODO

        public static final double INCHES_TO_METERS = 0.0254;
    }

    public static final class SwerveModule {
        // Profiling Values
        public static final double MAX_DRIVING_SPEED = 4.0; // m/s
        public static final double MAX_ANGLE_VELOCITY = Math.PI;
        public static final double MAX_ANGLE_ACCELERATION = SwerveModule.MAX_ANGLE_VELOCITY / 2;

        // Voltage Compensation
        public static final double VOLTAGE_COMPENSATION = 12.0;

        // Translation ID & Inverts | Front-Left, Front-Right, Back-Left, Back-Right
        public static final int[] TRANSLATION_IDS = { 0, 0, 0, 0 }; //TODO

        public static final boolean[] TRANSLATION_INVERTS = {false, false, false, false}; // TODO

        public static final int[] ROTATION_IDS = { 0, 0, 0, 0 }; //TODO

        public static final boolean[] ROTATION_INVERTS = { false, false, false, false }; // TODO

        public static final int[] CAN_CODER_IDS = { 0, 0, 0, 0 }; //TODO

        public static final double[] CAN_CODER_OFFSETS = { 0, 0, 0, 0 }; // TODO

        // Translation Motor Conversions
        public static final double TRANSLATION_GEAR_RATIO = 6.75;
        public static final double TRANSLATION_TO_POSITION = Constants.WHEEL_DIAMETER * Math.PI / TRANSLATION_GEAR_RATIO; // rotations to meters
        public static final double TRANSLATION_TO_VELOCITY = TRANSLATION_TO_POSITION / 60.0; // rotations to meters per 100ms

        //Current Limits
        public static final int TRANSLATION_CURRENT_LIMIT = 20;
        public static final int ROTATION_CURRENT_LIMIT = 80;


        // Rotation Motor Conversions
        public static final double ROTATION_GEAR_RATIO = 12.8;
        public static final double ROTATION_TO_ANGLE = 360.0 / ROTATION_GEAR_RATIO; // rotations to degrees

        // Translation PID values
        public static final double TRANSLATION_KP = 0.0; // TODO
        public static final double TRANSLATION_KI = 0.0; // TODO
        public static final double TRANSLATION_KD = 0.0; // TODO

        // Translation FF Values
        public static final double TRANSLATION_KS = 0; // TODO
        public static final double TRANSLATION_KV = 0; // TODO
        public static final double TRANSLATION_KA = 0; // TODO

        // Rotation PID Values
        public static final double ROTATION_KP = 0.0; // TODO
        public static final double ROTATION_KI = 0.0; 
        public static final double ROTATION_KD = 0.0; 
    }

    public static final class Drivetrain {
        public static final double MIN_OUTPUT = 0.01;

        // Profiled PID for theta (turning) control
        public static final double THETA_P = 0.0; // TODO
        public static final double THETA_I = 0.0;
        public static final double THETA_D = 0.0;
    }
}