// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.commands.SwerveManual;
import frc.robot.subsystems.Drivetrain;
import frc.robot.util.SwerveModule;
import harkerrobolib.joysticks.XboxGamepad;
import harkerrobolib.util.Constants;
import harkerrobolib.util.MathUtil;

/**
 * The VM is configured to automatically run this class, and to call the functions corresponding to
 * each mode, as described in the TimedRobot documentation. If you change the name of this class or
 * the package after creating this project, you must also update the build.gradle file in the
 * project.
 */
public class Robot extends TimedRobot {
  
  /**
   * This function is run when the robot is first started up and should be used for any
   * initialization code.
   * 
   * - Set SwerveManual as Drivetrain's default command
   */
  @Override
  public void robotInit() {
    /* INSERT CODE HERE! */
  }

  /**
   * This method is called every 20ms. Most methods are controlled by the CommandScheduler.
   * - get an instance of CommandScheduler and call the run method
   */
  @Override
  public void robotPeriodic() {
    /* INSERT CODE HERE! */
  }

  // leave below empty for now!
  @Override
  public void autonomousInit() {}

  @Override
  public void autonomousPeriodic() {}

  @Override
  public void teleopInit() {}

  @Override
  public void teleopPeriodic() {}

  @Override
  public void disabledInit() {}

  @Override
  public void disabledPeriodic() {}

  @Override
  public void testInit() {}

  @Override
  public void testPeriodic() {}

  @Override
  public void simulationInit() {}

  @Override
  public void simulationPeriodic() {}
}
