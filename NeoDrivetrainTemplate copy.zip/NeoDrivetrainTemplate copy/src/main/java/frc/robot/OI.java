package frc.robot;

import harkerrobolib.joysticks.XboxGamepad;
import harkerrobolib.util.Constants;

public class OI {
    private static OI instance;

    private XboxGamepad driver;
    private XboxGamepad operator;

    /*
     * Constructor for the OI class.
     * - Instantiate the driver and operator XboxGamepad using their respective ids
     */
    private OI() {
        /* INSERT CODE HERE!!! */
    }

    /**
     * @return the driver instance
     */

    public XboxGamepad getDriver() {
        /* INSERT CODE HERE!!! */
        return null; // replace
    }

    /**
     * @return the operator instance
     */

    public XboxGamepad getOperator() {
        /* INSERT CODE HERE!!! */
        return null; // replace
    }

    /**
     * Singleton Code
     * @return instance of OI
     */
    public static OI getInstance() {
        /* INSERT CODE HERE!!! */
        return null; // replace
    }
}